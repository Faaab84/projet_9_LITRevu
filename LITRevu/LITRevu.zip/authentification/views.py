from django.contrib.auth import login, logout, authenticate
from django.shortcuts import render, redirect
from .forms import CustomUserCreationForm, CustomAuthenticationForm, FollowUserForm
from .models import CustomUser
from django.contrib.auth.decorators import login_required
from django.contrib import messages

def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Inscription réussie ! Bienvenue.')
            return redirect('reviews:feed')
        else:
            messages.error(request, 'Erreur lors de l’inscription. Vérifiez vos informations.')
    else:
        form = CustomUserCreationForm()
    return render(request, 'register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = CustomAuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, 'Connexion réussie !')
            return redirect('reviews:feed')
        else:
            messages.error(request, 'Nom d’utilisateur ou mot de passe incorrect.')
    else:
        form = CustomAuthenticationForm()
    return render(request, 'login.html', {'form': form})

def logout_view(request):
    logout(request)
    messages.success(request, 'Déconnexion réussie.')
    return redirect('authentification:login')

@login_required
def follow_user(request):
    if request.method == 'POST':
        form = FollowUserForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            try:
                user_to_follow = CustomUser.objects.get(username=username)
                if user_to_follow != request.user:
                    request.user.following.add(user_to_follow)
                    messages.success(request, f"Vous suivez maintenant {username}.")
                else:
                    messages.error(request, "Vous ne pouvez pas vous suivre vous-même.")
            except CustomUser.DoesNotExist:
                messages.error(request, "Cet utilisateur n’existe pas.")
            return redirect('authentification:follow-user')
    else:
        form = FollowUserForm()
    followed_users = request.user.following.all()
    followers = request.user.followers.all()
    return render(request, 'authentification/follow_user.html', {'form': form, 'followed_users': followed_users, 'followers': followers})

@login_required
def unfollow_user(request, user_id):
    if request.method == 'POST':
        user_to_unfollow = CustomUser.objects.get(id=user_id)
        request.user.following.remove(user_to_unfollow)
        messages.success(request, f"Vous ne suivez plus {user_to_unfollow.username}.")
        return redirect('authentification:follow-user')
    return redirect('authentification:follow-user')
