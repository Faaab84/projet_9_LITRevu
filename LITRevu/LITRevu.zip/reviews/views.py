# reviews/views.py
from django.shortcuts import redirect, render
from django.urls import reverse
from django.db.models import CharField, Value
from itertools import chain
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import RequestBilletForm, RequestCommentaireForm
from .models import Billet, Commentaire

@login_required
def feed(request):
    commentaires = Commentaire.objects.filter(user__in=request.user.following.all()) | Commentaire.objects.filter(user=request.user)
    commentaires = commentaires.annotate(content_type=Value('COMMENTAIRE', CharField()))
    billets = Billet.objects.filter(user__in=request.user.following.all()) | Billet.objects.filter(user=request.user)
    billets = billets.annotate(content_type=Value('BILLET', CharField()))
    posts = sorted(chain(commentaires, billets), key=lambda post: post.time_created, reverse=True)
    return render(request, 'reviews/feed.html', {'posts': posts})

@login_required
def create_billet(request):
    if request.method == "POST":
        billet_form = RequestBilletForm(request.POST, request.FILES)
        if billet_form.is_valid():
            billet = billet_form.save(commit=False)
            billet.user = request.user
            billet.save()
            messages.success(request, "Billet créé avec succès.")
            return redirect("reviews:feed")
    else:
        billet_form = RequestBilletForm()
    return render(request, 'reviews/show_billet_form.html', {'billet_form': billet_form})

@login_required
def show_billet_form(request):
    title_view = "Billet"
    action_url = reverse("reviews:create-billet")
    billet_form = RequestBilletForm()
    context = {"billet_form": billet_form, "title_view": title_view, "action_url": action_url}
    return render(request, "reviews/show_billet_form.html", context)

@login_required
def edit_billet(request, billet_id):
    billet = Billet.objects.get(id=billet_id)
    if billet.user != request.user:
        messages.error(request, "Vous ne pouvez pas modifier ce billet.")
        return redirect('reviews:feed')
    if request.method == "POST":
        form = RequestBilletForm(request.POST, request.FILES, instance=billet)
        if form.is_valid():
            form.save()
            messages.success(request, "Billet modifié avec succès.")
            return redirect('reviews:feed')
    else:
        form = RequestBilletForm(instance=billet)
    return render(request, 'reviews/show_billet_form.html', {'billet_form': form, 'title_view': 'Modifier le billet', 'action_url': reverse('reviews:edit-billet', args=[billet_id])})

@login_required
def delete_billet(request, billet_id):
    if request.method == "POST":
        billet = Billet.objects.get(id=billet_id)
        if billet.user != request.user:
            messages.error(request, "Vous ne pouvez pas supprimer ce billet.")
            return redirect('reviews:feed')
        billet.delete()
        messages.success(request, "Billet supprimé avec succès.")
        return redirect('reviews:feed')
    return redirect('reviews:feed')

@login_required
def create_commentaire(request, billet_id=None):
    billet = None
    if billet_id:
        billet = Billet.objects.get(id=billet_id)
    if request.method == "POST":
        commentaire_form = RequestCommentaireForm(request.POST)
        if commentaire_form.is_valid():
            commentaire = commentaire_form.save(commit=False)
            commentaire.user = request.user
            commentaire.billet = billet
            commentaire.save()
            messages.success(request, "Commentaire créé avec succès.")
            return redirect("reviews:feed")
    else:
        commentaire_form = RequestCommentaireForm()
    return render(request, 'reviews/show_commentaire_form.html', {'commentaire_form': commentaire_form, 'billet': billet})

@login_required
def edit_commentaire(request, commentaire_id):
    commentaire = Commentaire.objects.get(id=commentaire_id)
    if commentaire.user != request.user:
        messages.error(request, "Vous ne pouvez pas modifier ce commentaire.")
        return redirect('reviews:feed')
    if request.method == "POST":
        form = RequestCommentaireForm(request.POST, instance=commentaire)
        if form.is_valid():
            form.save()
            messages.success(request, "Commentaire modifié avec succès.")
            return redirect('reviews:feed')
    else:
        form = RequestCommentaireForm(instance=commentaire)
    return render(request, 'reviews/show_commentaire_form.html', {'commentaire_form': form, 'billet': commentaire.billet})

@login_required
def delete_commentaire(request, commentaire_id):
    if request.method == "POST":
        commentaire = Commentaire.objects.get(id=commentaire_id)
        if commentaire.user != request.user:
            messages.error(request, "Vous ne pouvez pas supprimer ce commentaire.")
            return redirect('reviews:feed')
        commentaire.delete()
        messages.success(request, "Commentaire supprimé avec succès.")
        return redirect('reviews:feed')
    return redirect('reviews:feed')

@login_required
def create_billet_and_commentaire(request):
    if request.method == "POST":
        billet_form = RequestBilletForm(request.POST, request.FILES)
        commentaire_form = RequestCommentaireForm(request.POST)
        if billet_form.is_valid() and commentaire_form.is_valid():
            billet = billet_form.save(commit=False)
            billet.user = request.user
            billet.save()
            commentaire = commentaire_form.save(commit=False)
            commentaire.user = request.user
            commentaire.billet = billet
            commentaire.save()
            messages.success(request, "Billet et commentaire créés avec succès.")
            return redirect("reviews:feed")
    else:
        billet_form = RequestBilletForm()
        commentaire_form = RequestCommentaireForm()
    return render(request, 'reviews/billet_and_commentaire_form.html', {
        'billet_form': billet_form,
        'commentaire_form': commentaire_form,
    })
