
from django import forms
from .models import Billet, Commentaire


class RequestBilletForm(forms.ModelForm):
    class Meta:
        model = Billet
        fields = ['title', 'description', 'image']
        labels = {
            'title': 'Titre',
            'description': 'Description',
            'image': 'Image',
        }
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'aria-label': 'Titre'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'aria-label': 'Description'}),
            'image': forms.FileInput(attrs={'aria-label': 'Image'}),
        }


class RequestCommentaireForm(forms.ModelForm):
    class Meta:
        model = Commentaire
        fields = ['headline', 'rating', 'body']
        labels = {
            'headline': 'Titre du commentaire',
            'rating': 'Note',
            'body': 'Commentaire',
        }
        widgets = {
            'headline': forms.TextInput(attrs={'class': 'form-control', 'aria-label': 'Titre du commentaire'}),
            'rating': forms.Select(attrs={'class': 'form-control', 'aria-label': 'Note'}),
            'body': forms.Textarea(attrs={'class': 'form-control', 'aria-label': 'Commentaire'}),
        }
